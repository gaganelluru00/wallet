import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateAccountComponent } from './create-account/create-account.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { PrintTransactionsComponent } from './print-transactions/print-transactions.component';


const routes: Routes = [{path:'transfer/add',component:CreateAccountComponent},
{path:'transfer/deposit',component:DepositComponent},{path:'transfer/withdraw',component:WithdrawComponent},
{path:'transfer/fund',component:FundTransferComponent},{path:'show',component:ShowBalanceComponent},
{path:'print',component:PrintTransactionsComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
