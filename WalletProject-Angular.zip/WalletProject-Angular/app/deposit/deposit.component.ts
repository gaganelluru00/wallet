import { Component, OnInit } from '@angular/core';
import { AmountTransaction, HttpclientService,User} from '../service/httpclient.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
public username:String;
public password:String;
public accNumber:String;
public amount:String;
dep:AmountTransaction=new AmountTransaction("","","","");
user:User=new User("","","",0,"","","","","");


  constructor(private httpclientService:HttpclientService) { }

onDeposit(value:any){}

  ngOnInit(): void {
  }
  
  depositAmount():void{
    this.httpclientService.depositAmount(this.dep).subscribe( data => {this.getStatus(data);
      if(this.user.username=="Incorrect Username or Password")
      {alert("Incorrect Username or Password");}
      else{
      alert("Amount deposited in the account");}
    });

};

getStatus(data){
  this.user=data;
}

}
