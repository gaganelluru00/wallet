import { Component, OnInit } from '@angular/core';
import { AmountTransaction, HttpclientService ,User} from '../service/httpclient.service';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {
  public username:String;
  public password:String;
  public accNumber:String;
  public amount:String;
with:AmountTransaction=new AmountTransaction("","","","");
user:User=new User("","","",0,"","","","","");
  constructor(private httpclientService:HttpclientService) { }
onWithdraw(value:any){}
  ngOnInit(): void {
  }
  withdrawAmount():void{
    this.httpclientService.withdrawAmount(this.with).subscribe( data => {this.getData(data);
      
      if(data){
        if(this.user.username=="Incorrect Username or Password"){
          alert("Incorrect Username or Password");
        }
        else{
        alert("Balance in the account is "+this.user.accountBalance);}
      }
      if(data==null){
        alert("Insufficient Balance");
      }
    });

};
getData(data){
this.user=data;
}

}
