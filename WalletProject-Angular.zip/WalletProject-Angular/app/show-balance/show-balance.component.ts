import { Component, OnInit } from '@angular/core';
import { AmountTransaction, HttpclientService,User } from '../service/httpclient.service';

@Component({
  selector: 'app-show-balance',
  templateUrl: './show-balance.component.html',
  styleUrls: ['./show-balance.component.css']
})
export class ShowBalanceComponent implements OnInit {
bal:AmountTransaction=new AmountTransaction("","","","");
user:User=new User("","","",0,"","","","","");
balance:String="";

  constructor(private httpClientService:HttpclientService) { }
onBalance(value:any){}
  ngOnInit(): void {
  }
  getData(){
  this.httpClientService.getBalance(this.bal).subscribe( data => {this.setData(data);
    
  });

};
  
setData(data){
  this.user=data;
  this.balance=this.user.accountBalance.toString();
}
}
