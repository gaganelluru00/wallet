package com.wallet.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.wallet.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

	User findByAccountNumber(String accountNumber);
	User findByUsername(String username);
	User findByPassword(String password);
	User findByUserId(Long userId);
	int countByUsername(String username);
	int countByUserId(long userId);
	int countByUsernameAndPassword(String username,String password);
	int countByAccountNumber(String accountNumber);
	//@Query("from AccountDetails where username=?1 and password=?2 ")
	User findByUsernameAndPassword(String username,String password);
	@Modifying
	@Query("update User a set a.accountBalance=:accountBalance where a.username=:username and a.password=:password")
	void updateBalance(@Param("accountBalance")double amount,@Param("username")String username,@Param("password")String password);
}
